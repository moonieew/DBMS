CREATE PROC [dbo].[SP_RegisterCartDetail]
	@productid int,
	@cartid int,
	@price float,
	@quantity  int 
	
AS
BEGIN
	INSERT INTO [CartDetail] (productid, cartid, price, quantity) VALUES (@productid, @cartid, @price, @quantity)
END
go

