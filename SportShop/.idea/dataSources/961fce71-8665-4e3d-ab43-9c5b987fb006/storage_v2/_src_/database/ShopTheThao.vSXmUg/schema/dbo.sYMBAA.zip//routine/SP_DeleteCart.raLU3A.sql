CREATE PROC [dbo].[SP_DeleteCart]
	@id int,
	@userid int
AS
BEGIN
	DELETE  FROM [Cart] WHERE id = @id AND userid = @userid 
END
go

