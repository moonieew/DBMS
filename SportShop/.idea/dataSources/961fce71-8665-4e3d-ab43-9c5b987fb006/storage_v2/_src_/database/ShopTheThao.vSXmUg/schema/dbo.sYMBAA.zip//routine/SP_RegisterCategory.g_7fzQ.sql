CREATE PROC [dbo].[SP_RegisterCategory] 
	@name nvarchar(50) 
AS
BEGIN
	INSERT INTO Category([name]) 
	VALUES (@name);	
END
go

