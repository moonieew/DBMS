CREATE FUNCTION [dbo].[Func_GetCart] (@userid int)
RETURNS table AS
	RETURN SELECT * FROM [Carts] WHERE userid = @userid;
go

