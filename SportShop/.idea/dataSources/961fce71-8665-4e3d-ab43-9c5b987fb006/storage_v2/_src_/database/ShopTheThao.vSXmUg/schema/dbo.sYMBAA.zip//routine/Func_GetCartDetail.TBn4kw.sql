CREATE FUNCTION [dbo].[Func_GetCartDetail] (@cartid int)
RETURNS table AS
	RETURN SELECT * FROM [CartDetail] WHERE cartid = @cartid
go

