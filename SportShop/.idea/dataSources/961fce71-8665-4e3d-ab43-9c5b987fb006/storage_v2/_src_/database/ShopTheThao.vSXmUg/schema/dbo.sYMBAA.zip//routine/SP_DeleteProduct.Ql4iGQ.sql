CREATE PROC [dbo].[SP_DeleteProduct]
	@id int
AS
BEGIN
	DELETE FROM Product WHERE id=@id
END
go

