CREATE PROC [dbo].[SP_RegisterOrders]
	@quantity  int ,
	@shipping float, 
	@total float, 
	@grandtotal float,
	@userid int
AS
BEGIN
	DECLARE @createAt date = GETDATE();
	DECLARE @status int = 1;
	INSERT INTO [Orders] (createAt, status, quantity, shipping, total, grandtotal, userid) 
	VALUES (@createAt, @status, @quantity, @shipping, @total, @grandtotal, @userid);
END
go

