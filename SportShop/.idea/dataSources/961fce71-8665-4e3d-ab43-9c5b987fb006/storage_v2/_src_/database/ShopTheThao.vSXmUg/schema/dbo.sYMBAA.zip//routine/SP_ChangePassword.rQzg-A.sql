CREATE PROC [dbo].[SP_ChangePassword] @username nvarchar(50), @old_pass_input nvarchar(50), @new_pass nvarchar(50), @repassword nvarchar(50)
AS
BEGIN
	DECLARE @old_password nvarchar(50) = (SELECT password FROM [User] WHERE username = @username);
	IF(@old_pass_input != '' AND @new_pass != '' AND @repassword != '')
	BEGIN
		IF(@old_pass_input = @old_password AND @new_pass != @old_password AND @new_pass = @repassword)
			UPDATE [User] SET password = @new_pass WHERE username = @username
	END
END
go

