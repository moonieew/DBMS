CREATE PROC [dbo].[SP_RegisterOrderDetail]
	@productid int,
	@orderid int,
	@price float,
	@quantity  int
AS
BEGIN
	INSERT INTO [OrderDetail] (productid, orderid, price, quantity) 
	VALUES (@productid, @orderid, @price, @quantity);
END
go

