CREATE PROC [dbo].[SP_EditCart]
	@cartid int,
	@quantity  int ,
	@shipping float,
	@total float, 
	@grandtotal float 
	
AS
BEGIN
	UPDATE [Carts] SET quantity = @quantity , shipping = @shipping, total = @total, grandtotal = @grandtotal 
	WHERE id = @cartid
END
go

