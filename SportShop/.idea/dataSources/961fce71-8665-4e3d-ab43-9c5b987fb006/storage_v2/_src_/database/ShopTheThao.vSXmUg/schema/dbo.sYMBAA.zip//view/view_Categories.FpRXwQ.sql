CREATE VIEW [dbo].[view_Categories]
AS
SELECT * FROM Category
go

