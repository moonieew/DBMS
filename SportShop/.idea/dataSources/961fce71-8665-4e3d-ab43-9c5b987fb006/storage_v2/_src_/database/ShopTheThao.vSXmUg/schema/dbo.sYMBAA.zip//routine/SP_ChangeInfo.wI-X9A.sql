CREATE PROC [dbo].[SP_ChangeInfo] 
	@id INT, 
	@fname  nvarchar(50), 
	@lname nvarchar(50), 
	@phone nvarchar(50), 
	@email nvarchar(50), 
	@address nvarchar(50)
AS
	UPDATE [User] SET fname=@fname, lname=@lname, phone=@phone, email = @email, address = @address WHERE id = @id
go

