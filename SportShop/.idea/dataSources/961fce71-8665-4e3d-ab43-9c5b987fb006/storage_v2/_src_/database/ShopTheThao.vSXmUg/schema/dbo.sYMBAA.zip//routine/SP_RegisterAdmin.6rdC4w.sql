CREATE PROC [dbo].[SP_RegisterAdmin] 
	@username nvarchar(50), 
	@password nvarchar(50), 
	@fname  nvarchar(50),
	@lname nvarchar(50), 
	@gender int, 
	@phone nvarchar(50), 
	@email nvarchar(50), 
	@address nvarchar(50)
AS
BEGIN
	IF (@username != '' AND @password != '')
		IF (NOT EXISTS (SELECT * FROM [User] WHERE username=@username))
			BEGIN
				INSERT INTO [User] (username, password, fname, lname, gender, phone, email, address, roleid) 
				VALUES (@username, @password, @fname, @lname, @gender, @phone, @email, @address, 1);
			END
END
go

