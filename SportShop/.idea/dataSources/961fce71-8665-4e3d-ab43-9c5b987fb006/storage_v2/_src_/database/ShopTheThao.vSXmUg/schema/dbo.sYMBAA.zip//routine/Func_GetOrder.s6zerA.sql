CREATE FUNCTION [dbo].[Func_GetOrder] (@userid int)
RETURNS TABLE
AS
RETURN
SELECT * FROM Orders WHERE userid = @userid
go

