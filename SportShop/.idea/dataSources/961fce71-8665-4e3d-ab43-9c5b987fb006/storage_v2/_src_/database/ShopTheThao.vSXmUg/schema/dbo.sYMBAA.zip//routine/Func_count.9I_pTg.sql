CREATE FUNCTION [dbo].[Func_count] (@categoryid int, @search nvarchar(50))
RETURNS TABLE
AS
RETURN
SELECT DISTINCT  (
        SELECT COUNT(*)
        FROM [User]
        ) AS CountUser,
        (
        SELECT COUNT(*)
        FROM Product
        ) AS CountAllProduct,
		(SELECT COUNT(*)
		FROM Product WHERE categoryid = @categoryid) AS CountByCategory,
		(SELECT COUNT(*)
        FROM Product WHERE CONCAT(id,[name]) like @search ) AS CountBySearch
FROM  [User],Product
go

