CREATE PROC [dbo].[SP_RegisterProduct] 
	@productname nvarchar(100), 
	@price float, 
	@saleprice  float,
	@quantity int, 
	@description nvarchar(500), 
	@image nvarchar(MAX), 
	@brandid int, 
	@categoryid int
AS
BEGIN
	IF (NOT EXISTS (SELECT * FROM [Product] WHERE [name] = @productname))
		BEGIN
			INSERT INTO [Product] ([name], price, saleprice, quantity, [description], [image], brandid, categoryid) 
			VALUES (@productname, @price, @saleprice, @quantity, @description, @image, @brandid, @categoryid);
		END
END
go

