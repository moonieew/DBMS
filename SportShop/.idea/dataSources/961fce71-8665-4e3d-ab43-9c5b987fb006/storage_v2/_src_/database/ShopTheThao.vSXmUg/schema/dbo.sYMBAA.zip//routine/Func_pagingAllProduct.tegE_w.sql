CREATE FUNCTION [dbo].[Func_pagingAllProduct](@pageNumber int, @rowsOfPage int)
RETURNS TABLE
AS
RETURN
(
    SELECT * FROM Product
	ORDER BY id 
	OFFSET (@pageNumber-1)*@rowsOfPage ROWS
	FETCH NEXT @rowsOfPage ROWS ONLY
)
go

