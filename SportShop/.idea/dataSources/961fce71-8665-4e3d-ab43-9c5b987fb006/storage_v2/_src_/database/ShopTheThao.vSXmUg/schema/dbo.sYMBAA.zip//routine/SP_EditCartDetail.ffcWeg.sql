CREATE PROC [dbo].[SP_EditCartDetail]
	@productid int,
	@cartid int,
	@price float,
	@quantity  int 
	
AS
BEGIN
	UPDATE [CartDetail] SET price = @price , quantity = @quantity
	WHERE productid = @productid AND cartid = @cartid
END
go

