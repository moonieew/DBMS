CREATE FUNCTION [dbo].[Func_pagingProductBySearch] (@pageNumber int, @rowsOfPage int, @search nvarchar(50))
RETURNS TABLE
AS
RETURN
(
    SELECT * FROM Product
	WHERE CONCAT(id,[name]) like @search
	ORDER BY id
	OFFSET (@pageNumber-1)*@rowsOfPage ROWS
	FETCH NEXT @rowsOfPage ROWS ONLY
)
go

