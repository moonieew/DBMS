CREATE VIEW [dbo].[view_Brands]
AS
SELECT * FROM Brand
go

