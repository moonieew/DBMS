CREATE FUNCTION [dbo].[Func_pagingProductByCategoryId] (@pageNumber int, @rowsOfPage int, @categoryId int)
RETURNS TABLE
AS
RETURN
(
    SELECT * FROM Product
	WHERE categoryid = @categoryId
	ORDER BY id
	OFFSET (@pageNumber-1)*@rowsOfPage ROWS
	FETCH NEXT @rowsOfPage ROWS ONLY
)
go

