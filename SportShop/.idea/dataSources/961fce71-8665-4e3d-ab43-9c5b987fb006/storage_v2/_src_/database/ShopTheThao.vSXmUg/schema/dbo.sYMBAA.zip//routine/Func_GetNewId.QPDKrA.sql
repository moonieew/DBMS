CREATE FUNCTION [dbo].[Func_GetNewId] (@userid int)
RETURNS TABLE
AS
RETURN
	SELECT MAX(id) AS MAXID FROM Orders WHERE userid = @userid
go

