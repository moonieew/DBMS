CREATE PROC [dbo].[SP_DeleteAllCartDetail]
	@cartid int
AS
BEGIN
	DELETE  FROM [CartDetail] WHERE cartid = @cartid 
END
go

