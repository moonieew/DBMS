CREATE PROC [dbo].[SP_EditProduct] 
	@id int,
	@productname nvarchar(100), 
	@price float, 
	@saleprice  float,
	@quantity int, 
	@description nvarchar(500), 
	@image nvarchar(MAX), 
	@brandid int, 
	@categoryid int
AS
BEGIN
	UPDATE [Product] SET [name]=@productname, price=@price, 
	saleprice = @saleprice, quantity=@quantity, [description]=@description,
	[image]=@image, brandid=@brandid, categoryid = @categoryid
	WHERE id = @id
END
go

