CREATE PROC [dbo].[SP_DeleteCartDetail]
	@productid int,
	@cartid int
AS
BEGIN
	DELETE  FROM [CartDetail] WHERE productid = @productid AND cartid = @cartid 
END
go

