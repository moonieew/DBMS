CREATE PROC [dbo].[SP_DeleteCategory] 
	@id int 
AS
BEGIN
	DELETE FROM Category
	WHERE id = @id
END
go

