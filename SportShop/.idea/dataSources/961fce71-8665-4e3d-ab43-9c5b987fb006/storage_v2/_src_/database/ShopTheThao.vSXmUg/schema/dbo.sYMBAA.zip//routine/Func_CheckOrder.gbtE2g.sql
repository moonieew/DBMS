CREATE FUNCTION [dbo].[Func_CheckOrder] (@userid int, @status int)
RETURNS table AS
	RETURN SELECT * FROM [Orders] WHERE userid = @userid AND status = @status
go

