CREATE PROC [dbo].[SP_DeleteUser] 
	@id nvarchar(50) 
AS
BEGIN
	DELETE FROM [User]
	WHERE id = @id
END
go

