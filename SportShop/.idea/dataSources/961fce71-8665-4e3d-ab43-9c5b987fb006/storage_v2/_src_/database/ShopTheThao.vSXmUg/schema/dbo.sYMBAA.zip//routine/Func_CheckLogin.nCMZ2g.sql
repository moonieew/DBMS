CREATE FUNCTION [dbo].[Func_CheckLogin] (
	@username nvarchar(50), 
	@password nvarchar(50))
RETURNS int
AS
BEGIN
		DECLARE @flag int
		IF EXISTS (SELECT * FROM [User] WHERE username=@username AND password = @password)
			RETURN 1
		ELSE
			RETURN 0
		RETURN 0
END
go

