CREATE FUNCTION [dbo].[Func_pagingUser](@pageNumber int, @rowsOfPage int)
RETURNS TABLE
AS
RETURN
(
    SELECT * FROM [User]
	ORDER BY id 
	OFFSET (@pageNumber-1)*@rowsOfPage ROWS
	FETCH NEXT @rowsOfPage ROWS ONLY
)
go

