CREATE PROC [dbo].[SP_RegisterCart]
	@userid int,
	@quantity  int = 0,
	@shipping float = 0, 
	@total float = 0, 
	@grandtotal float = 0
	
AS
BEGIN
		IF (NOT EXISTS (SELECT * FROM [Carts] WHERE userid = @userid))
			BEGIN
				INSERT INTO [Carts] (quantity, shipping, total, grandtotal, userid) 
				VALUES (@quantity, @shipping, @total, @grandtotal, @userid);
			END
END
go

